<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="asset" tilewidth="16" tileheight="16" tilecount="625" columns="25">
 <image source="../images/Tiles/Assets/Assets.png" trans="000000" width="400" height="400"/>
</tileset>
