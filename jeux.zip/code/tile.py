import pygame
from fonctions import get_x_y_from_id
from settings import *


class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, tile_id, spritesheet):
        super().__init__()
        self.id = int(tile_id)    # typecast from str to int
        load_pos = get_x_y_from_id(self.id)
        self.image = pygame.Surface((SPRITE_SIZE, SPRITE_SIZE))
        self.image.blit(
            spritesheet, (0, 0), (load_pos[0]*SPRITE_SIZE, load_pos[1]*SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)
        )
        self.image.set_colorkey((255, 255, 255))
        self.image = pygame.transform.scale(self.image, (TILE_SIZE, TILE_SIZE))
        self.rect = self.image.get_rect(topleft=pos)

    def update_x(self, x_shift):
        self.rect.x += x_shift * SPEED

    def update_y(self, y_shift):
        self.rect.y += y_shift * SPEED


class DefaultGroup(pygame.sprite.Group):
    def __init__(self):
        super().__init__()

    def update_x(self, x_shift, speed, dt):
        for sprite in self:
            sprite.rect.x += x_shift * speed * dt

    def update_y(self, y_shift, dt):
        for sprite in self:
            sprite.rect.y += y_shift * SPEED * dt


class CollidesGroup(DefaultGroup):
    def __init__(self):
        super().__init__()


class VisibleGroup(DefaultGroup):
    def __init__(self):
        super().__init__()

    def update_x(self, x_shift, speed, dt):
        for sprite in self:
            if not str(type(sprite)) == "<class 'player.Player'>":
                sprite.rect.x += x_shift * speed * dt

    def update_y(self, y_shift, dt):
        for sprite in self:
            if not str(type(sprite)) == "<class 'player.Player'>":
                sprite.rect.y += y_shift * SPEED * dt


class BackgroundGroup(DefaultGroup):
    def __init__(self):
        super().__init__()


class PlayerGroup(DefaultGroup):
    def __init__(self):
        super().__init__()

    def update_x(self, _, __, ___):
        return None

    def update_y(self, _, __):
        return None


class ToptileGroup(DefaultGroup):
    def __init__(self):
        super().__init__()


class ForegroundGroup(DefaultGroup):
    def __init__(self):
        super().__init__()


class MiscGroup(DefaultGroup):
    def __init__(self):
        super().__init__()


class GrassGroup(DefaultGroup):
    def __init__(self):
        super().__init__()


class BridgeGroup(DefaultGroup):
    def __init__(self):
        super().__init__()


class HiddenGroup(DefaultGroup):
    def __init__(self):
        super().__init__()
